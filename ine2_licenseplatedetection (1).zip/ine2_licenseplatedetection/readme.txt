Bonjour

Pour que le code fonctionne:

D'abord installer les requirements

Puis télécharger le fichier des poids du modèle yolov3-320.weights à partir du lien https://drive.google.com/uc?id=1jQPLyibctn8b333a91Lnt3Yl468_H62r&export=download
et le mettre dans le répértoire courant

Puis télécharger les autres fichiers de poids https://github.com/HamzaEzzRa/MLPDR/tree/main/weights et les mettre dans le dossier weights comme sur le lien